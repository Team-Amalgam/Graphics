Place any "Object.obj" file in the same directory as the ourBetterGraphics_eyy_.exe file and it'll render it!

Controls

W,A,S,D - move Up, Left, Down, Right
I, K    - move Forward , Backward
T,F,G,H,R,Y - move Light Up, Left, Down, Right, Backward, Forward
J, L    - rotate Left, Right
Z - toggle Wireframe
X - toggle Coloring